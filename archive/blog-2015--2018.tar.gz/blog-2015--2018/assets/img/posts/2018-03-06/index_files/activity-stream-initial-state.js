// Note - this is a generated file.
window.gActivityStreamPrerenderedState = {
  "TopSites": {
    "initialized": false,
    "rows": [],
    "editForm": {
      "visible": false,
      "site": null
    }
  },
  "App": {
    "initialized": false,
    "version": null
  },
  "Snippets": {
    "initialized": false
  },
  "Prefs": {
    "initialized": true,
    "values": {
      "migrationExpired": true,
      "showTopSites": true,
      "showSearch": true,
      "topSitesCount": 6,
      "collapseTopSites": false,
      "section.highlights.collapsed": false,
      "section.topstories.collapsed": false,
      "feeds.section.topstories": true,
      "feeds.section.highlights": true
    }
  },
  "Dialog": {
    "visible": false,
    "data": {}
  },
  "Sections": [
    {
      "title": {
        "id": "header_recommended_by",
        "values": {
          "provider": "Pocket"
        }
      },
      "rows": [],
      "order": 1,
      "enabled": true,
      "icon": "pocket",
      "id": "topstories",
      "initialized": false
    },
    {
      "title": {
        "id": "header_highlights"
      },
      "rows": [],
      "order": 2,
      "enabled": true,
      "id": "highlights",
      "icon": "highlights",
      "initialized": false
    }
  ],
  "PreferencesPane": {
    "visible": false
  }
};
